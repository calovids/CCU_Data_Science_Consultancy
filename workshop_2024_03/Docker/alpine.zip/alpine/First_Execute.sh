pip install --upgrade pip
pip install tensorflow==2.4
pip install numpy==1.22
/usr/sbin/sshd  -D

